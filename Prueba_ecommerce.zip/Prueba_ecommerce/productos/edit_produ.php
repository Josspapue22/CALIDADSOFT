<?php
include(__DIR__ . '/../includes/mysql.php');

$db = new Database();
$conexion = $db->conectar();

if (!isset($_GET['id'])) {
    header('Location: index3.php');
    exit;
}

$id = intval($_GET['id']);

// Obtener datos actuales del producto
try {
    $stmt = $conexion->prepare("SELECT * FROM producto WHERE id_producto = :id");
    $stmt->execute(['id' => $id]);
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$producto) {
        echo "Producto no encontrado.";
        exit;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $id_categoria = $_POST['id_categoria'];

    // Manejar imagen si suben una nueva
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen = $_FILES['imagen']['name'];
        $ruta = 'uploads/' . $imagen;
        move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta);
    } else {
        // Mantener la imagen actual si no suben nueva
        $imagen = $producto['imagen_url'];
    }

    // Actualizar
    try {
        $sql = "UPDATE producto SET 
                nombre_producto = :nombre, 
                descripcion = :descripcion,
                precio = :precio, 
                stock = :stock, 
                id_categoria = :id_categoria, 
                imagen_url = :imagen
                WHERE id_producto = :id";

        $stmt = $conexion->prepare($sql);
        $stmt->execute([
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'precio' => $precio,
            'stock' => $stock,
            'id_categoria' => $id_categoria,
            'imagen' => $imagen,
            'id' => $id
        ]);

        header('Location: index3.php');
        exit;
    } catch (PDOException $e) {
        echo "Error al actualizar: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../css/styl_edipro.css" />
</head>
<body class="container">
    <h2>Editar Producto</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-2">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($producto['nombre_producto']) ?>">
        </div>
        <div class="mb-2">
            <label>Descripción:</label>
            <textarea name="descripcion" class="form-control" required><?= htmlspecialchars($producto['descripcion']) ?></textarea>
        </div>
        <div class="mb-2">
            <label>Precio:</label>
            <input type="number" step="0.01" name="precio" class="form-control" required value="<?= htmlspecialchars($producto['precio']) ?>">
        </div>
        <div class="mb-2">
            <label>Stock:</label>
            <input type="number" name="stock" class="form-control" required value="<?= htmlspecialchars($producto['stock']) ?>">
        </div>
        <div class="mb-2">
            <label>Categoría (ID):</label>
            <input type="number" name="id_categoria" class="form-control" value="<?= htmlspecialchars($producto['id_categoria']) ?>">
        </div>
        <div class="mb-2">
            <label>Imagen actual:</label><br>
            <?php if ($producto['imagen_url']): ?>
                <img src="../<?= htmlspecialchars($producto['imagen_url']) ?>" alt="Imagen actual" class="miniatura">
            <?php else: ?>
                <span class="sin-imagen">Sin imagen</span>
            <?php endif; ?>
        </div>
        <div class="mb-2">
            <label>Subir nueva imagen (opcional):</label>
            <input type="file" name="imagen" class="form-control">
        </div>
        <button class="btn btn-primary">Guardar Cambios</button>
        <a href="index3.php" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>