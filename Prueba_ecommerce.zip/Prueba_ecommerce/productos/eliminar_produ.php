<?php
include('../includes/mysql.php');

$db = new Database();
$conexion = $db->conectar();

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index3.php");
    exit;
}

$id = intval($_GET['id']);

try {
    // Obtener la imagen actual del producto
    $stmt = $conexion->prepare("SELECT imagen_url FROM producto WHERE id_producto = :id");
    $stmt->execute(['id' => $id]);
    $producto = $stmt->fetch(PDO::FETCH_ASSOC);
 
    if ($producto && $producto['imagen_url']) {
        $rutaImagen = 'uploads/' . $producto['imagen_url'];
        if (file_exists($rutaImagen)) {
            unlink($rutaImagen); // Eliminar archivo del servidor
        }
    }

    // Eliminar producto de la base de datos
    $stmt = $conexion->prepare("DELETE FROM producto WHERE id_producto = :id");
    $stmt->execute(['id' => $id]);

    header("Location: index3.php");
    exit;

} catch (PDOException $e) {
    echo "Error al eliminar: " . $e->getMessage();
    exit;
}
?>