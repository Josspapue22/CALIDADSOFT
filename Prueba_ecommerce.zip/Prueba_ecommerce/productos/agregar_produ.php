<?php
include(__DIR__ . '/../includes/mysql.php');

$db = new Database();
$conexion = $db->conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $id_categoria = $_POST['id_categoria'];

    // Subir imagen
    $imagen_url = null;
    if (!empty($_FILES['imagen']['name'])) {
        $nombreImagen = uniqid() . '_' . basename($_FILES['imagen']['name']);
        $rutaImagen = __DIR__ . '/../uploads/' . $nombreImagen; // ruta absoluta para move_uploaded_file
        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaImagen)) {
            $imagen_url = 'uploads/' . $nombreImagen;
        } else {
            echo "<div class='alert alert-danger'>Error al subir la imagen.</div>";
            exit;
        }
    }

    try {
        $stmt = $conexion->prepare("INSERT INTO producto (nombre_producto, descripcion, precio, stock, id_categoria, imagen_url)
                                     VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nombre, $descripcion, $precio, $stock, $id_categoria, $imagen_url]);
        header("Location: index3.php");
        exit;
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger'>Error al guardar: " . $e->getMessage() . "</div>";
    }
}

// Consultar categorías
$sql = "SELECT id_categoria, nombre_categoria FROM categoria";
$categorias = $conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">
    <h2 class="mb-4">➕ Agregar Producto</h2>

    <form method="post" enctype="multipart/form-data" class="border p-4 rounded bg-light">

        <div class="mb-3">
            <label class="form-label">Nombre:</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción:</label>
            <textarea name="descripcion" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Precio:</label>
            <input type="number" step="0.01" name="precio" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Stock:</label>
            <input type="number" name="stock" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Categoría:</label>
            <select name="id_categoria" class="form-select" required>
                <option value="" selected disabled>-- Selecciona una categoría --</option>
                <?php foreach ($categorias as $categoria): ?>
                    <option value="<?= $categoria['id_categoria'] ?>"><?= $categoria['nombre_categoria'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Imagen:</label>
            <input type="file" name="imagen" class="form-control" required>
        </div>

        <div class="d-flex justify-content-between">
            <button class="btn btn-success">Guardar</button>
            <a href="index3.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</body>
</html>
