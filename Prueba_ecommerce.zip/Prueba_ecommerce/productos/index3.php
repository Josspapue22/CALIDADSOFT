
<?php
include(__DIR__ . '/../includes/mysql.php');

$db = new Database();
$conexion = $db->conectar();

try {
    $stmt = $conexion->query("SELECT * FROM producto");
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Error al obtener productos: " . $e->getMessage() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Productos</title>
    <link rel="stylesheet" href="../css/styl_prod.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <header>
        <h1>🛍️  Listado de Productos</h1>
        <a href="agregar_produ.php" class="btn btn-primary">➕ Agregar nuevo producto</a>
    </header>

    <main>
        <table class="tabla-productos">
            <thead>
                <tr>
                    <th>Imagen</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Categoría</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($productos)): ?>
                    <?php foreach ($productos as $producto): ?>
                        <tr>
                            <td>
                                <?php if ($producto['imagen_url']): ?>
                                    <img src="../<?= htmlspecialchars($producto['imagen_url']) ?>" alt="Imagen de <?= htmlspecialchars($producto['nombre_producto']) ?>" class="miniatura">
                                <?php else: ?>
                                    <span class="sin-imagen">Sin imagen</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($producto['nombre_producto']) ?></td>
                            <td><?= htmlspecialchars($producto['descripcion']) ?></td>
                            <td>$<?= number_format($producto['precio'], 2) ?></td>
                            <td><?= intval($producto['stock']) ?></td>
                            <td><?= intval($producto['id_categoria']) ?></td>
                            <td class="acciones">
                             <a href="edit_produ.php?id=<?= $producto['id_producto'] ?>" title="Editar producto" class="btn-editar">✏️</a>
                             <a href="eliminar_produ.php?id=<?= $producto['id_producto'] ?>" class="btn-eliminar" onclick="return confirm('¿Seguro que deseas eliminar este producto?')">🗑</a>
                             </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="no-productos">No hay productos para mostrar</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
<a href="../inicio.php" class="btn-regresar">⬅ Volver al Inicio</a>
</body>
</html>
