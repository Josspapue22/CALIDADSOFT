<?php
  require_once 'includes/mysql.php'; // para secure_data
  $db   = new Database();
  $conn = $db->conectar();

  $errores = [];
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $nombre       = secure_data($_POST['nombre'] ?? '');
      $descripcion  = secure_data($_POST['descripcion'] ?? '');

      if ($nombre === '') { $errores[] = "El nombre es obligatorio"; }

      if (!$errores) {
          $sql = "INSERT INTO categoria (nombre_categoria, descripcion)
                  VALUES (:nombre, :descripcion)";
          $stmt = $conn->prepare($sql);
          $stmt->bindParam(':nombre', $nombre);
          $stmt->bindParam(':descripcion', $descripcion);
          $stmt->execute();

          // Redirige al listado con mensaje flash
          header('Location: categorias.php?mensaje=Categoría+creada');
          exit;
      }
  }
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Nueva Categoría</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">

  <h2 class="mb-4">➕ Nueva Categoría</h2>

  <?php if ($errores): ?>
      <div class="alert alert-danger">
        <?php foreach ($errores as $e) echo "<div>$e</div>"; ?>
      </div>
  <?php endif; ?>

  <form method="POST">
      <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($nombre ?? '') ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Descripción (opcional)</label>
        <textarea name="descripcion" rows="3" class="form-control"><?= htmlspecialchars($descripcion ?? '') ?></textarea>
      </div>

      <button class="btn btn-success">Guardar</button>
      <a href="categorias.php" class="btn btn-secondary">Cancelar</a>
  </form>
</body>
</html>
