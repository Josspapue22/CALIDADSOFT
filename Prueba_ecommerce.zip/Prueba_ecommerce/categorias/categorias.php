<?php
  require_once 'includes/mysql.php';   // tu archivo con la clase Database
  $db   = new Database();
  $conn = $db->conectar();

  // Traer categorías ordenadas (la más reciente primero)
  $stmt = $conn->prepare("SELECT * FROM categoria ORDER BY id_categoria DESC");
  $stmt->execute();
  $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Categorías</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">

  <h2 class="mb-3">📁 Lista de Categorías</h2>

  <!-- Botón para ir al formulario -->
  <a href="agregar_categoria.php" class="btn btn-primary mb-3">+ Nueva Categoría</a>

  <!-- Mensaje flash opcional -->
  <?php if (isset($_GET['mensaje'])): ?>
     <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered align-middle">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Descripción</th>
        <th style="width:160px;">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($categorias): ?>
         <?php foreach ($categorias as $cat): ?>
           <tr>
             <td><?= $cat['id_categoria'] ?></td>
             <td><?= htmlspecialchars($cat['nombre_categoria']) ?></td>
             <td><?= htmlspecialchars($cat['descripcion']) ?></td>
             <td>
               <a href="editar_categoria.php?id=<?= $cat['id_categoria'] ?>" class="btn btn-sm btn-warning">✏️ Editar</a>
               <a href="eliminar_categoria.php?id=<?= $cat['id_categoria'] ?>" 
                  class="btn btn-sm btn-danger"
                  onclick="return confirm('¿Eliminar la categoría?');">🗑️ Eliminar</a>
             </td>
           </tr>
         <?php endforeach; ?>
      <?php else: ?>
           <tr><td colspan="4" class="text-center">Sin categorías aún</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
