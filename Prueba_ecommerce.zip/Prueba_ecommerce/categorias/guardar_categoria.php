<?php
include 'includes/mysql.php';

$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];

$query = "INSERT INTO categoria (nombre, descripcion) VALUES ('$nombre', '$descripcion')";
mysqli_query($mysql, $query);

header("Location: categorias.php");
?>
