<?php
require_once 'includes/mysql.php';

$db = new Database();
$conn = $db->conectar(); // Conexión PDO

require 'includes/funciones.php';
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Administracion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css"> <!-- opcional -->
</head>
<body>

<!-- Sidebar -->
<div class="sidebar d-flex flex-column">
    <h4 class="text-center py-3 border-bottom">TIENDA</h4>
  <a href="inicio.php" class="menu-button">🏠 Menu</a>
<a href="#" class="menu-button">👤 Usuarios</a>
<a href="#" class="menu-button">📋 Clientes</a>
<a href="productos/index3.php" class="menu-button">🛍 Productos</a>
<a href="#" class="menu-button">🧾 Pedidos</a>
<a href="#" class="menu-button">📈 Ventas</a>
<a href="#" class="menu-button">📋Categorias</a>
<a href="logout.php" class="mt-auto text-danger">❌  Cerrar sesión</a>
</div>

<!-- Contenido Principal -->
<div class="main-content">
    <div class="container-fluid">
        <h1 class="mb-4">Bienvenida Jacqueline</h1>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5>Usuarios</h5>
                        <h3><?= totalUsuarios($conn) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5>Clientes</h5>
                        <h3><?= totalClientes($conn) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-warning">
                    <div class="card-body">
                        <h5>Productos</h5>
                        <h3><?= totalProductos($conn) ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card text-white bg-danger">
                    <div class="card-body">
                        <h5>Pedidos</h5>
                        <h3><?= totalPedidos($conn) ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-5">
            <h4>Ingresos Totales</h4>
            <div class="alert alert-info fs-4">
                $<?= totalIngresos($conn) ?>
            </div>
        </div>

        <div class="mt-5">
            <h4>📦 Pedidos Recientes</h4>
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>ID Pedido</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Método de Pago</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $pedidos = obtenerPedidosRecientes($conn);
                    foreach ($pedidos as $row):
                    ?>
                    <tr>
                        <td><?= $row['id_pedido'] ?></td>
                        <td><?= $row['nombre_completo'] ?></td>
                        <td><?= $row['fecha_pedido'] ?></td>
                        <td><?= ucfirst($row['estado']) ?></td>
                        <td><?= $row['metodo_pago'] ?></td>
                        <td>$<?= number_format($row['total'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-5">
            <h4>🔥 Productos Más Vendidos</h4>
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>Producto</th>
                        <th>Cantidad Vendida</th>
                        <th>Ingresos Generados</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $productos = productosMasVendidos($conn);
                    foreach ($productos as $row):
                    ?>
                    <tr>
                        <td><?= $row['nombre_producto'] ?></td>
                        <td><?= $row['total_vendido'] ?></td>
                        <td>$<?= number_format($row['ingresos'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Formulario Categorías (oculto inicialmente) -->
<div id="formularioCategorias" style="display: none;">
  <?php include 'categorias/categorias.php';?>
</div>
</body>
</html>