<?php
function esNulo(array $parametros) {
    foreach ($parametros as $valor) {
        if (strlen(trim($valor)) < 1) {
            return true;
        }
    }
    return false;
}

function login($usuario, $password, $conexion) {
    $sql = $conexion->prepare("SELECT id_usuario, nombre_usuario, contrasena, rol 
                               FROM usuario 
                               WHERE nombre_usuario = ?  
                               LIMIT 1");
    $sql->execute([$usuario]);

    if ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        if (password_verify($password, $row['contrasena'])) {
            session_start();
            $_SESSION['user_id'] = $row['id_usuario'];
            $_SESSION['user_name'] = $row['nombre_usuario'];
            $_SESSION['user_type'] = $row['rol']; // Asigna el rol real
            header('Location: inicio.php');
            exit;
        }
    }

    return 'El usuario y/o la contraseña son incorrectos';
}


?>