<?php

function totalUsuarios($conn) {
    $sql = "SELECT COUNT(*) AS total FROM Usuario";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total'];
}

function totalClientes($conn) {
    $sql = "SELECT COUNT(*) AS total FROM Cliente";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total'];
}

function totalProductos($conn) {
    $sql = "SELECT COUNT(*) AS total FROM Producto";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total'];
}

function totalPedidos($conn) {
    $sql = "SELECT COUNT(*) AS total FROM Pedido";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total'];
}

function totalIngresos($conn) {
    $sql = "SELECT SUM(total) AS ingresos FROM Pedido WHERE estado IN ('pagado','enviado','entregado')";
    $stmt = $conn->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return number_format($row['ingresos'] ?? 0, 2);
}

function obtenerPedidosRecientes($conn, $limite = 5) {
    $sql = "
        SELECT P.id_pedido, C.nombre_completo, P.fecha_pedido, P.estado, P.metodo_pago, P.total
        FROM Pedido P
        JOIN Cliente C ON P.id_cliente = C.id_cliente
        ORDER BY P.fecha_pedido DESC
        LIMIT :limite
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function productosMasVendidos($conn, $limite = 5) {
    $sql = "
        SELECT PR.nombre_producto, SUM(V.cantidad) AS total_vendido, SUM(V.subtotal) AS ingresos
        FROM Ventas V
        JOIN Producto PR ON V.id_producto = PR.id_producto
        GROUP BY V.id_producto
        ORDER BY total_vendido DESC
        LIMIT :limite
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

