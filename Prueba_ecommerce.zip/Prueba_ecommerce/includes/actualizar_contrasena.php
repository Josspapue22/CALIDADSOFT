<?php
header('Content-Type: application/json');
require_once 'mysql.php'; // Asegúrate de que esté bien la ruta

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST["correo"]) || !isset($_POST["contrasena"])) {
        echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
        exit;
    }

    $correo = trim($_POST["correo"]);
    $contrasena = trim($_POST["contrasena"]);
    $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT);

    try {
        $db = new Database();
        $conexion = $db->conectar();

        $stmt = $conexion->prepare("SELECT id_usuario FROM usuario WHERE email = ?");
        $stmt->execute([$correo]);

        if ($stmt->rowCount() > 0) {
            $update = $conexion->prepare("UPDATE usuario SET contrasena = ? WHERE email = ?");
            $update->execute([$contrasena_hash, $correo]);

            echo json_encode(["status" => "ok", "message" => "Contraseña actualizada correctamente"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Correo no encontrado"]);
        }
        exit;
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Error en la base de datos"]);
        exit;
    }
}
?>
