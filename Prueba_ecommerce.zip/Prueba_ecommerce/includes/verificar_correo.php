<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Incluye tu clase Database
require_once 'mysql.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST["correo"])) {
        echo json_encode(["status" => "error", "message" => "Falta el correo"]);
        exit;
    }

    $correo = secure_data($_POST["correo"]);

    try {
        $db = new Database();
        $conexion = $db->conectar();

        $stmt = $conexion->prepare("SELECT id_usuario FROM usuario WHERE email = ?");
        $stmt->execute([$correo]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(["status" => "ok"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Correo no encontrado"]);
        }
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Error de base de datos"]);
    }
}
