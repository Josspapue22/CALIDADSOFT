<?php
 
		function secure_data($data){
			$data = trim($data);
	        $data = stripslashes($data);
	        $data = htmlspecialchars($data);
	
	        return $data;
		}

       function hash_password($password){
			return password_hash($password, PASSWORD_DEFAULT);
		}
      class Database {
    private $hostname = 'localhost';
    private $database = 'ecommerce_cosmeticos';
    private $username = 'root';
    private $password = '';
    private $charset  = 'utf8';

    public function conectar() {
         try {
            $conexion = new PDO(
                "mysql:host=$this->hostname;dbname=$this->database;charset=$this->charset",
                $this->username,
                $this->password
            );
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conexion;
        } catch (PDOException $e) {
            header('Content-Type: application/json');
            echo json_encode([
                "status" => "error",
                "message" => "Error de conexión a la base de datos"
                // "debug" => $e->getMessage() // útil si estás en desarrollo
            ]);
            exit();
        }
    }
}
?>
