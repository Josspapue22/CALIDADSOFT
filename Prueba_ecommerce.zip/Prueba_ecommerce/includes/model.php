<!-- Modal de recuperación de contraseña -->
<div id="modal-forgot" class="modal-overlay">
  <div class="modal-content">
    <span class="modal-close" onclick="cerrarModal()">&times;</span>
    <h3>Recuperar contraseña</h3>
    <p>Ingresa tu correo electrónico:</p>
    <input type="email" id="correo" class="modal-input" placeholder="Correo electrónico" />
    <small id="error-correo" style="color: red; display: none;"></small>
    <button class="modal-btn" onclick="validarCorreo()">Enviar</button>

  </div>
</div>

<!-- Modal de nueva contraseña -->
<div id="modal-nueva" class="modal-overlay">
  <div class="modal-content">
    <span class="modal-close" onclick="cerrarModal()">&times;</span>
    <h3>Restablecer contraseña</h3>
    <input type="password" id="nueva" class="modal-input" placeholder="Nueva contraseña" />
    <input type="password" id="confirmar" class="modal-input" placeholder="Confirmar contraseña" />
    <button class="modal-btn" onclick="actualizarContrasena()">Confirmar</button>
  </div>
</div>

<!-- Estilos personalizados para los formularios (no afecta login) -->
<style>
  .modal-overlay {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0; top: 0;
    width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.6);
    justify-content: center;
    align-items: center;
  }

  .modal-content {
    background: white;
    padding: 20px;
    border-radius: 8px;
    width: 90%;
    max-width: 400px;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    position: relative;
    font-family: 'Century Gothic', sans-serif;
  }

  .modal-close {
    position: absolute;
    top: 8px;
    right: 12px;
    font-size: 24px;
    color: #999;
    cursor: pointer;
  }

  .modal-input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
  }

  .modal-btn {
    background-color: #1f5c85;
    color: white;
    padding: 10px;
    width: 100%;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  .modal-btn:hover {
    background-color: #174566;
  }
</style>

<!-- Script -->
<script>
  function abrirModal() {
    document.getElementById('modal-forgot').style.display = 'flex';
  }

  function mostrarModalNueva() {
    document.getElementById('modal-forgot').style.display = 'none';
    document.getElementById('modal-nueva').style.display = 'flex';
  }

  function cerrarModal() {
    document.getElementById('modal-forgot').style.display = 'none';
    document.getElementById('modal-nueva').style.display = 'none';
  }

  // Cerrar al hacer clic fuera
  window.onclick = function(e) {
    if (e.target.classList.contains('modal-overlay')) {
      cerrarModal();
    }
  }
</script>
<!-- Tu script de funciones de modal -->
<script>
  function abrirModal() {
    document.getElementById('modal-forgot').style.display = 'flex';
  }

  function mostrarModalNueva() {
    document.getElementById('modal-forgot').style.display = 'none';
    document.getElementById('modal-nueva').style.display = 'flex';
  }

  function cerrarModal() {
    document.getElementById('modal-forgot').style.display = 'none';
    document.getElementById('modal-nueva').style.display = 'none';
  }

  window.onclick = function(e) {
    if (e.target.classList.contains('modal-overlay')) {
      cerrarModal();
    }
  }
</script>

<!-- ✅ Aquí pones la validación del correo -->
<script>
  function validarCorreo() {
    const correo = document.getElementById('correo').value.trim();
    const error = document.getElementById('error-correo');
    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (correo === '' || !regexCorreo.test(correo)) {
      error.textContent = "Por favor, ingresa un correo válido.";
      error.style.display = 'block';
      return;
    }
fetch('includes/verificar_correo.php', {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  body: `correo=${encodeURIComponent(correo)}`
})
.then(response => response.json())
.then(data => {
  if (data.status === 'ok') {
    error.style.display = 'none';
    mostrarModalNueva();
  } else {
    error.textContent = data.message;
    error.style.display = 'block';
  }
})

  }
</script>
<!-- Tu script de funcion nueva contraseña -->

<script>
function actualizarContrasena() {
  const correo = document.getElementById('correo').value.trim(); // viene del primer modal
  const nueva = document.getElementById('nueva').value.trim();
  const confirmar = document.getElementById('confirmar').value.trim();

  if (nueva === '' || confirmar === '') {
    alert("Por favor completa ambos campos.");
    return;
  }

  if (nueva !== confirmar) {
    alert("Las contraseñas no coinciden.");
    return;
  }

  fetch('includes/actualizar_contrasena.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `correo=${encodeURIComponent(correo)}&contrasena=${encodeURIComponent(nueva)}`
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'ok') {
      alert("Contraseña actualizada correctamente.");
      cerrarModal(); // Cierra los modales
    } else {
      alert(data.message);
    }
  })
  .catch(err => {
    console.error('Error:', err);
    alert("Ocurrió un error.");
  });
}
</script>
