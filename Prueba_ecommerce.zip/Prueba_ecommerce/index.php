<?php
  include_once('includes/mysql.php');
  include ('clases/AdminFunciones.php');

   $db = new Database();
   $conexion = $db->conectar();

  // Datos a insertar
/*$nombre_usuario = 'Admin_jaqueline';
$email = 'jacqui-piruch.84@hotmail.com';
$password = password_hash('admin', PASSWORD_DEFAULT);
$rol = 'admin';

// Preparar la consulta con marcadores
$sql = "INSERT INTO usuario (nombre_usuario, email, contrasena, rol) VALUES (:nombre, :email, :contrasena, :rol)";
$stmt = $conexion->prepare($sql);

// Ejecutar pasando un array asociativo con los valores
$stmt->execute([
    ':nombre' => $nombre_usuario,
    ':email' => $email,
    ':contrasena' => $password,
    ':rol' => $rol
]);

echo "Usuario insertado correctamente";*/
$mensaje = ''; // Variable para mensajes de error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener y sanitizar datos del formulario
    $usuario = secure_data($_POST['usuario']);
    $password = $_POST['password']; // No aplicar sanitización a la contraseña para no alterar la cadena

    if (esNulo([$usuario, $password])) {
        $mensaje = "Por favor, complete todos los campos.";
    } else {
        // Llamar a la función login que devuelve mensaje de error o redirige
        $resultado = login($usuario, $password, $conexion);
        if ($resultado !== null) {
            // Si retorna mensaje, es error
            $mensaje = $resultado;
        }
        // Si login es exitoso, la función redirige y no sigue acá
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Login</title>
  <link rel="stylesheet" href="css/login.css" />
</head>
<body>
  <div class="container">
    <div class="heading">
      <span class="span1">- JACQUI <span> -STORE-</span></span><br />
      <span class="span2">ADMIN</span>
      <hr />
    </div>

    <?php if (isset($mensaje) && $mensaje): ?>
      <p style="color:red; text-align:center;"><?php echo $mensaje; ?></p>
    <?php endif; ?>

    <form id="loginform" method="post" action="index.php">
      <input class="user" type="text" name="usuario" maxlength="28" placeholder="usuario" required />
      <input class="pass" type="password" name="password" maxlength="16" placeholder="Contraseña" required />

      <div class="remdiv">
        <input class="remcheck" type="checkbox" name="remember" />
        <span class="remspan">Recordar nombre de usuario</span>
        <span class="forgot">
          <a href="#" onclick="abrirModal(); return false;">¿Olvidaste la contraseña?</a>
        </span>
      </div>

      <button class="submit" type="submit" value="Ingreso">Ingreso</button>
    </form>

    <div class="bydiv">
      <span>All rights reserved 2025 &copy; Glamwear</span>
    </div>

    <hr class="socialhr" />
    <a href="https://www.facebook.com/MohanedKhaledMohamed" target="_blank" title="Facebook">
      <div class="fb"></div>
    </a>
  </div>

  <!-- Incluir el modal aquí -->
  <?php include 'includes/model.php'; ?>

</body>
</html>

